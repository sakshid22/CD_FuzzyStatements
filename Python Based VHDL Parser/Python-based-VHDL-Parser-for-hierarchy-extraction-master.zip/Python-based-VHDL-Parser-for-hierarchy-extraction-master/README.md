Python-based-VHDL-Parser-for-hierarchy-extraction
=================================================

VHDL Hierarchy Tracer